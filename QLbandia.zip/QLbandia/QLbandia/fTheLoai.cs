﻿using QLbandia.DAO;
using QLbandia.dtos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLbandia
{
    public partial class fTheLoai : Form
    {
        public fTheLoai()
        {
            InitializeComponent();
            LoadTheLoai();
        }

        private void fTheLoai_Load(object sender, EventArgs e)
        {

        }

        public void LoadTheLoai()
        {
            List<TheLoai> tl = TheLoaiDAO.Instance.GetListCategory();
            dgvTheLoai.DataSource = tl;
        }

        public void Refresh()
        {
            txtMaTL.Text = "";
            txtTenTL.Text = "";
            txtMaTL.Focus();
        }
        private void btnThem_Click(object sender, EventArgs e)
        {
            string matl = txtMaTL.Text.ToUpper();
            string tentl = txtTenTL.Text;

            int check = TheLoaiDAO.Instance.GetUnCheckTLByMaTL(matl);

            if (check == -1)
            {
                TheLoaiDAO.Instance.InsertTheLoai(matl, tentl);
            }
            else
            {
                MessageBox.Show("Mã thể loại đã tồn tại");
            }
            LoadTheLoai();
            Refresh();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string matl = txtMaTL.Text;
            TheLoaiDAO.Instance.DeleteTheLoai(matl);
            LoadTheLoai();
            Refresh();
        }

        private void dgvTheLoai_Click(object sender, EventArgs e)
        {
            txtMaTL.Text = dgvTheLoai.CurrentRow.Cells[0].Value.ToString();
            txtTenTL.Text = dgvTheLoai.CurrentRow.Cells[1].Value.ToString();
            txtMaTL.Enabled = false;
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            string matl = txtMaTL.Text;
            string tentl = txtTenTL.Text;
            TheLoaiDAO.Instance.SuaTL(matl,tentl);
            LoadTheLoai();
            Refresh();
        }
    }
}
