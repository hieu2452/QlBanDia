﻿using QLbandia.DAO;
using QLbandia.dtos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Windows.Media.Imaging;

namespace QLbandia
{
    public partial class fStoreManager : Form
    {
        public fStoreManager()
        {
            InitializeComponent();
            HienThi();
            //LoadDia();
        }

        #region method

        public void HienThi()
        {

            HienTheLoaiTheoID();
            HienNSXTheoID();
            HienThiMaDia();
            HienThiNhanVien();
            HienThiNhaCungCap();
            HienThiKhachHang();

            cbNSX.SelectedIndex = -1;
            cbTheLoai.SelectedIndex = -1;
            LoadDia();
        }

        public void LoadDia()
        {
            flStore.Controls.Clear();

            List<Dia> dialist = DiaDAO.Instance.LoadDiaList();

            foreach( Dia item in dialist)
            {
                Button btn = new Button() { Width = DiaDAO.DiaWidth, Height = DiaDAO.DiaHeight };
                btn.Text = item.Tendia;
                btn.BackgroundImage = Image.FromFile(item.Anh);
                btn.BackgroundImageLayout = ImageLayout.Stretch;
                btn.Tag = item;
                btn.Click += btn_Click;

                flStore.Controls.Add(btn);


            }

            
          
        }
        void HienTheLoaiTheoID()
        {
            List<TheLoai> listTheLoai = TheLoaiDAO.Instance.GetListCategory();
            cbTheLoai.DataSource = listTheLoai;
            cbTheLoai.DisplayMember = "TenTL";
            cbTheLoai.ValueMember = "MaTL";
        }

        void HienNSXTheoID()
        {
            List<NSX> listTheLoai = NsxDAO.Instance.GetListCategory();
            cbNSX.DataSource = listTheLoai;
            cbNSX.DisplayMember = "TenNSX";
            cbNSX.ValueMember = "MANSX";
        }

        void HienThiMaDia()
        {
            List<Dia> listDia = DiaDAO.Instance.LoadDiaList();
            cbMaDia.DataSource = listDia;
            cbMaDia.DisplayMember = "TenDia";
            cbMaDia.ValueMember = "MaDia";
        }

        void HienThiNhanVien()
        {
            List<NhanVien> listnv = NhanVienDAO.Instance.GetAllNhanVien();
            cbNV.DataSource = listnv;
            cbNV.DisplayMember = "TenNV";
            cbNV.ValueMember = "MaNV";
        }

        void HienThiNhaCungCap()
        {
            List<NhaCungCap> listncc = NhaCungCapDAO.Instance.GetAllNhaCC();
            cbNCC.DataSource = listncc;
            cbNCC.DisplayMember = "TenNCC";
            cbNCC.ValueMember = "MaNCC";
        }

        void HienThiKhachHang()
        {
            List<KhachHang> listkh = KhachHangDAO.Instance.GetAllKhachHang();
            cbKH.DataSource = listkh;
            cbKH.DisplayMember = "TenKH";
            cbKH.ValueMember = "MaKH";
        }

        void ShowBill(string Madia)
        {
            lsvKhoDia.Items.Clear();
            Dia dia = DiaDAO.Instance.GetDiaByMaDia(Madia);
            ListViewItem lsvItem = new ListViewItem(dia.Madia);
            lsvItem.SubItems.Add(dia.Tendia);
            lsvItem.SubItems.Add(dia.Soluong.ToString());
            lsvItem.SubItems.Add(dia.Dongianhap.ToString());
            lsvItem.SubItems.Add(dia.Dongiaban.ToString());
            lsvKhoDia.Items.Add(lsvItem);
        }

        

        void LoadDiaByNSXvaMaTL(string id, string id1)
        {
            flStore.Controls.Clear();

            List<Dia> dialist = DiaDAO.Instance.GetDiaByMaNSXvaMaTL(id, id1);

            foreach (Dia item in dialist)
            {
                Button btn = new Button() { Width = DiaDAO.DiaWidth, Height = DiaDAO.DiaHeight };
                btn.Text = item.Tendia;
                btn.BackgroundImage = Image.FromFile(item.Anh);
                btn.BackgroundImageLayout = ImageLayout.Stretch;
                btn.Tag = item;
                btn.Click += btn_Click;

                flStore.Controls.Add(btn);


            }
        }

        void LoadDiaByTheLoai(string id)
        {
            flStore.Controls.Clear();

            List<Dia> dialist = DiaDAO.Instance.GetDiaByMaTheLoai(id);

            foreach (Dia item in dialist)
            {
                Button btn = new Button() { Width = DiaDAO.DiaWidth, Height = DiaDAO.DiaHeight };
                btn.Text = item.Tendia;
                btn.BackgroundImage = Image.FromFile(item.Anh);
                btn.BackgroundImageLayout = ImageLayout.Stretch;
                btn.Tag = item;
                btn.Click += btn_Click;

                flStore.Controls.Add(btn);


            }
        }


        #endregion


        #region event

        private void btn_Click(object sender, EventArgs e)
        {
            
            string MaDia = ((sender as Button).Tag as Dia).Madia;
            lsvKhoDia.Tag = (sender as Button).Tag;

            ShowBill(MaDia);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //MessageBox.Show(button1.BackgroundImage.ToString());
        }

        private void fStoreManager_Load(object sender, EventArgs e)
        {
           // button1.BackgroundImage = ((System.Drawing.Image)(Properties.Resources.gowdvd));
           
        }

        void LoadDiaByNSX(string id)
        {
            flStore.Controls.Clear();

            List<Dia> dialist = DiaDAO.Instance.GetDiaByMaNSX(id);

            foreach (Dia item in dialist)
            {
                Button btn = new Button() { Width = DiaDAO.DiaWidth, Height = DiaDAO.DiaHeight };
                btn.Text = item.Tendia;
                btn.BackgroundImage = Image.FromFile(item.Anh);
                btn.BackgroundImageLayout = ImageLayout.Stretch;
                btn.Tag = item;
                btn.Click += btn_Click;

                flStore.Controls.Add(btn);


            }
        }

        #endregion

        private void btnNhapHang_Click(object sender, EventArgs e)
        {
            Dia slectdia = cbMaDia.SelectedItem as Dia;
            string madia = slectdia.Madia;

            NhanVien selectnv = cbNV.SelectedItem as NhanVien;
            string manv = selectnv.Manv;

            NhaCungCap selectncc = cbNCC.SelectedItem as NhaCungCap;
            string mancc = selectncc.Mancc;

            string sohdn = txtSoHDN.Text;

            int soluong = (int)numSL.Value;
            
            int numcheck = HoaDonNhapDAO.Instance.GetUnCheckHDByMaHD(sohdn);

            
            if(numcheck == -1)
            {
                HoaDonNhapDAO.Instance.InsertHoaDonNhap(sohdn, manv, mancc);
                ChiTietHDNDAO.Instance.InsertChiTietHDN(sohdn, madia, soluong);
            }
            else
            {
                ChiTietHDNDAO.Instance.InsertChiTietHDN(sohdn, madia, soluong);
            }
        
            
            //MessageBox.Show("YES I CAN");
        }

        private void button2_Click(object sender, EventArgs e)
        {

            if (cbTheLoai.SelectedIndex > -1 && cbNSX.SelectedIndex > -1)
            {
                string maNSX = "";
                string maTL = "";


                if (cbNSX.SelectedItem == null && cbTheLoai.SelectedItem == null)
                    return;

                TheLoai selected1 = cbTheLoai.SelectedItem as TheLoai;
                maTL = selected1.Matl;
                NSX selected = cbNSX.SelectedItem as NSX;
                maNSX = selected.MaNSX;
                maTL = selected1.Matl;

                LoadDiaByNSXvaMaTL(maNSX, maTL);
            }
            else if (cbTheLoai.SelectedIndex > -1)
            {
                string maTL = "";


                if (cbTheLoai.SelectedItem == null)
                    return;

                TheLoai selected = cbTheLoai.SelectedItem as TheLoai;
                maTL = selected.Matl;
                LoadDiaByTheLoai(maTL);

            }
            else if (cbNSX.SelectedIndex > -1)
            {
                string maNSX = "";


                if (cbNSX.SelectedItem == null)
                    return;

                NSX selected = cbNSX.SelectedItem as NSX;
                maNSX = selected.MaNSX;
                LoadDiaByNSX(maNSX);
            }
        }

        private void btnLamMoi_Click(object sender, EventArgs e)
        {
            HienThi();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {

        }

        private void themeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            
        }

        private void thêmNSXToolStripMenuItem_Click(object sender, EventArgs e)
        {
            fNoiSanXuat fsx = new fNoiSanXuat();
            fsx.Show();
        }

        private void flStore_Paint(object sender, PaintEventArgs e)
        {

        }

        private void thêmThểLoạiToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void numSL_ValueChanged(object sender, EventArgs e)
        {

        }
    }
}
