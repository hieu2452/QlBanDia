﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLbandia.dtos
{
    public class HoaDonNhap
    {
        private string sohoadon;
        private string manv;
        private DateTime ngaynhap;
        private string soncc;
        private float tongtien;

        public HoaDonNhap()
        {

        }

        public HoaDonNhap(string sohoadon, string manv, DateTime ngaynhap, string soncc, float tongtien)
        {
            this.sohoadon = sohoadon;
            this.manv = manv;
            this.ngaynhap = ngaynhap;
            this.soncc = soncc;
            this.tongtien = tongtien;
        }


        public HoaDonNhap(DataRow row)
        {

            this.Sohoadon = row["SoHDN"].ToString();
            this.Manv = row["MaNV"].ToString();
            this.Ngaynhap = DateTime.Parse(row["NgayNhap"].ToString());
            this.Soncc = row["MaNCC"].ToString();
            this.tongtien = float.Parse(row["TongTien"].ToString());
        }

        public string Sohoadon { get => sohoadon; set => sohoadon = value; }
        public string Manv { get => manv; set => manv = value; }
        public DateTime Ngaynhap { get => ngaynhap; set => ngaynhap = value; }
        public string Soncc { get => soncc; set => soncc = value; }
        public float Tongtien { get => tongtien; set => tongtien = value; }
    }
}
