﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLbandia.dtos
{
    public class KhachHang
    {
        private string makh;
        private string tenkh;
        private string diachi;
        private int dienthoai;

        public KhachHang() { }



        public KhachHang(string makh, string tenkh, string diachi, int dienthoai)
        {
            this.makh = makh;
            this.tenkh = tenkh;
            this.diachi = diachi;
            this.dienthoai = dienthoai;
        }

        public KhachHang(DataRow row)
        {
            this.Makh = row["MaKH"].ToString();
            this.Tenkh = row["TenKH"].ToString();
            this.Diachi = row["DiaChi"].ToString();
            this.Dienthoai = Int32.Parse(row["DienThoai"].ToString());
        }

        public string Makh { get => makh; set => makh = value; }
        public string Tenkh { get => tenkh; set => tenkh = value; }
        public string Diachi { get => diachi; set => diachi = value; }
        public int Dienthoai { get => dienthoai; set => dienthoai = value; }
    }
}
