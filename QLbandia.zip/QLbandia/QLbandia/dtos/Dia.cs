﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLbandia.dtos
{
    public class Dia
    {
        private string madia;
        private string tendia;
        private int soluong;
        private float dongiaban;
        private float dongianhap;
        private string mansx;
        private string matl;
        private string anh;
        private string ghichu;


        public Dia()
        {

        }

        public Dia(string madia, string tendia, int soluong, float dongiaban, float dongianhap, string mansx, string matl, string anh, string ghichu)
        {
            this.madia = madia;
            this.tendia = tendia;
            this.soluong = soluong;
            this.dongiaban = dongiaban;
            this.dongianhap = dongianhap;
            this.mansx = mansx;
            this.matl = matl;
            this.anh = anh;
            this.ghichu = ghichu;
        }

        public Dia(DataRow row)
        {
            this.Madia = row["MaDia"].ToString();
            this.Tendia = row["TenDia"].ToString();
            this.Soluong = (int)row["SoLuong"];
            this.Dongianhap = float.Parse(row["DonGiaBan"].ToString());
            this.Dongiaban = float.Parse(row["DonGiaNhap"].ToString());
            this.Mansx = row["MaNSX"].ToString();
            this.Matl = row["MaTL"].ToString();
            this.Anh = row["Anh"].ToString();
            this.Ghichu = row["GhiChu"].ToString();
        }


        public string Madia { get => madia; set => madia = value; }
        public string Tendia { get => tendia; set => tendia = value; }
        public int Soluong { get => soluong; set => soluong = value; }
        public float Dongiaban { get => dongiaban; set => dongiaban = value; }
        public float Dongianhap { get => dongianhap; set => dongianhap = value; }
        public string Mansx { get => mansx; set => mansx = value; }
        public string Matl { get => matl; set => matl = value; }
        public string Anh { get => anh; set => anh = value; }
        public string Ghichu { get => ghichu; set => ghichu = value; }
    }
}
