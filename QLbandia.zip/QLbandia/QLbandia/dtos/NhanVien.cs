﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLbandia.dtos
{
    public class NhanVien
    {
        private string manv;
        private string tennv;
        private string gioitinh;
        private DateTime ngaysinh;
        private int sdt;
        private string diachi;
        private string macv;

        public NhanVien() { }

      

        public NhanVien(DataRow row)
        {
            this.Manv = row["MaNV"].ToString();
            this.Tennv = row["TenNV"].ToString();
            this.Gioitinh = row["GioiTinh"].ToString();
            this.Ngaysinh = DateTime.Parse(row["NgaySinh"].ToString());
            this.Sdt = Int32.Parse(row["DienThoai"].ToString());
            this.Diachi = row["DiaChi"].ToString();
            this.Macv = row["MaCV"].ToString();
        }

        public NhanVien(string manv, string tennv, string gioitinh, DateTime ngaysinh, int sdt, string diachi, string macv)
        {
            this.Manv = manv;
            this.Tennv = tennv;
            this.Gioitinh = gioitinh;
            this.Ngaysinh = ngaysinh;
            this.Sdt = sdt;
            this.Diachi = diachi;
            this.Macv = macv;
        }

        public string Manv { get => manv; set => manv = value; }
        public string Tennv { get => tennv; set => tennv = value; }
        public string Gioitinh { get => gioitinh; set => gioitinh = value; }
        public DateTime Ngaysinh { get => ngaysinh; set => ngaysinh = value; }
        public int Sdt { get => sdt; set => sdt = value; }
        public string Diachi { get => diachi; set => diachi = value; }
        public string Macv { get => macv; set => macv = value; }
    }
}
