﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLbandia.dtos
{
    public class NSX
    {
        private string maNSX;
        private string tenNSX;



        public NSX(DataRow row)
        {
            this.maNSX = row["MaNSX"].ToString();
            this.tenNSX = row["TenNSX"].ToString();
        }

        public NSX(string maNSX, string tenNSX)
        {
            this.MaNSX = maNSX;
            this.TenNSX = tenNSX;
        }

        public string MaNSX { get => maNSX; set => maNSX = value; }
        public string TenNSX { get => tenNSX; set => tenNSX = value; }
    }
}
