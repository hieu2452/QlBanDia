﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLbandia.dtos
{
    public class ChiTietHDN
    {
        private string sohdn;
        private string madia;
        private int soluong;
        private int giamgia;
        private float dongia;
        private float thanhtien;


        public ChiTietHDN()
        {

        }
        public ChiTietHDN(string sohdn, string madia, int soluong, int giamgia, float dongia, float thanhtien)
        {
            this.Sohdn = sohdn;
            this.Madia = madia;
            this.Soluong = soluong;
            this.Giamgia = giamgia;
            this.Dongia = dongia;
            this.Thanhtien = thanhtien;
        }

        public ChiTietHDN(DataRow row)
        {

            this.Sohdn = row["SoHDN"].ToString();
            this.Madia = row["MaDia"].ToString();
            this.Soluong = Int32.Parse(row["SoLuong"].ToString());
            this.Giamgia = Int32.Parse(row["GiamGia"].ToString());
            this.Dongia = float.Parse(row["DonGia"].ToString());
            this.Thanhtien = float.Parse(row["ThanhTien"].ToString());
        }

        public string Sohdn { get => sohdn; set => sohdn = value; }
        public string Madia { get => madia; set => madia = value; }
        public int Soluong { get => soluong; set => soluong = value; }
        public int Giamgia { get => giamgia; set => giamgia = value; }
        public float Dongia { get => dongia; set => dongia = value; }
        public float Thanhtien { get => thanhtien; set => thanhtien = value; }

    }
}
