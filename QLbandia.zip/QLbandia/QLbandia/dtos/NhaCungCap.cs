﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLbandia.dtos
{
    public class NhaCungCap
    {
        private string mancc;
        private string tenncc;
        private string diachi;
        private int sdt;

       
        public NhaCungCap()
        {

        }
        public NhaCungCap(string mancc, string tenncc, string diachi, int sdt)
        {
            this.mancc = mancc;
            this.tenncc = tenncc;
            this.diachi = diachi;
            this.sdt = sdt;
        }

        public NhaCungCap(DataRow row)
        {

            this.Mancc = row["MaNCC"].ToString();
            this.Tenncc = row["TenNCC"].ToString();
            this.Diachi = row["DiaChi"].ToString();
            this.Sdt = Int32.Parse(row["DienThoai"].ToString());
        }

        public string Mancc { get => mancc; set => mancc = value; }
        public string Tenncc { get => tenncc; set => tenncc = value; }
        public string Diachi { get => diachi; set => diachi = value; }
        public int Sdt { get => sdt; set => sdt = value; }

    }
}
