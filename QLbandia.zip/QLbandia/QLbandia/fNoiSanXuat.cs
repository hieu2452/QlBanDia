﻿using QLbandia.DAO;
using QLbandia.dtos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace QLbandia
{
    public partial class fNoiSanXuat : Form
    {
        public fNoiSanXuat()
        {
            InitializeComponent();

            LoadNoiSX();
        }

        private void fNoiSanXuat_Load(object sender, EventArgs e)
        {

        }
        public void Refresh()
        {
            txtMaSX.Text = "";
            txtTenSX.Text = "";
            txtMaSX.Focus();
        }
        private void btnThem_Click(object sender, EventArgs e)
        {
            string mansx = txtMaSX.Text.ToUpper();
            string tennsx = txtTenSX.Text;

            int check = NsxDAO.Instance.GetUnCheckNSXByMaNSX(mansx);
            if (check == -1)
            {
                NsxDAO.Instance.InsertNoiSX(mansx, tennsx);
            }
            else
            {
                MessageBox.Show("Nha San Xuat da ton tai");

                Refresh();
            }
            LoadNoiSX();
            Refresh();
        }


        private void dgvNoiSX_Click(object sender, EventArgs e)
        {
            txtMaSX.Text = dgvNoiSX.CurrentRow.Cells[0].Value.ToString();
            txtTenSX.Text = dgvNoiSX.CurrentRow.Cells[1].Value.ToString();
            txtMaSX.Enabled = false;
        }

        public void LoadNoiSX()
        {
            List<NSX> dnsx = NsxDAO.Instance.GetListCategory();
            dgvNoiSX.DataSource = dnsx;
        }

        private void dgvNoiSX_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string mansx = txtMaSX.Text;
            NsxDAO.Instance.DeleteNoiSX(mansx);
            LoadNoiSX();
            Refresh();
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            string mansx = txtMaSX.Text;
            string tennsx = txtTenSX.Text;
            NsxDAO.Instance.SuaNoiSX(mansx, tennsx);
            LoadNoiSX();
            Refresh();
        }
    }
}
