﻿using QLbandia.dtos;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLbandia.DAO
{
    public class ChiTietHDNDAO
    {
        private static ChiTietHDNDAO instance;

        public static ChiTietHDNDAO Instance
        {
            get { if (instance == null) instance = new ChiTietHDNDAO(); return ChiTietHDNDAO.instance; }
            private set { ChiTietHDNDAO.instance = value; }
        }

        public void InsertChiTietHDN(string shdn, string madia, int sl)
        {
            DataProvider.Instance.ExecuteNonQuery("exec ThemChiTietHoaDonNhap @sohdn, @madia , @soluong ", new object[] { shdn, madia, sl });
        }


    }
}
