﻿
using QLbandia.dtos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLbandia.DAO
{
    public class DiaDAO
    {
        private static DiaDAO instance;

        public static DiaDAO Instance
        {
            get { if (instance == null) instance = new DiaDAO(); return DiaDAO.instance; }
            private set { DiaDAO.instance = value; }
        }

        public static int DiaWidth = 90;
        public static int DiaHeight = 90;

        private DiaDAO() { }



        public List<Dia> LoadDiaList()
        {
            List<Dia> dialist = new List<Dia>();

            DataTable data = DataProvider.Instance.ExecuteQuery("USP_GetAlbumList");

            foreach (DataRow item in data.Rows)
            {
                Dia dia = new Dia(item);
                dialist.Add(dia);
            }

            return dialist;
        }


        public List<Dia> GetDiaByMaNSXvaMaTL(string madia, string madia1)
        {
            List<Dia> list = new List<Dia>();

            string query = $"select * from tKhoDia where MaNSX = N'{madia}' and MaTL = N'{madia1}'";
            DataTable data = DataProvider.Instance.ExecuteQuery(query);
            foreach (DataRow item in data.Rows)
            {
                Dia dia = new Dia(item);
                list.Add(dia);
            }

            return list;
        }
        public Dia GetDiaByMaDia(string madia)
        {
            
            string query = $"select * from tKhoDia where MaDia = N'{madia}'";
            DataTable data = DataProvider.Instance.ExecuteQuery(query);
            Dia dia = new Dia(data.Rows[0]);
            return dia;
        }

        public List<Dia> GetDiaByMaTheLoai(string madia)
        {
            List<Dia> list = new List<Dia>();

            string query = $"select * from tKhoDia where MaTL = N'{madia}'";
            DataTable data = DataProvider.Instance.ExecuteQuery(query);
            foreach (DataRow item in data.Rows)
            {
                Dia dia = new Dia(item);
                list.Add(dia);
            }

            return list;
        }

        public List<Dia> GetDiaByMaNSX(string madia)
        {
            List<Dia> list = new List<Dia>();

            string query = $"select * from tKhoDia where MaNSX = N'{madia}'";
            DataTable data = DataProvider.Instance.ExecuteQuery(query);
            foreach (DataRow item in data.Rows)
            {
                Dia dia = new Dia(item);
                list.Add(dia);
            }

            return list;
        }


        public void InsertDia(string madia, string tendia, int sl, string mansx, string matl, string anh, string gc )
        {
            DataProvider.Instance.ExecuteNonQuery("exec ThemDia @madia , @tendia , @sl , @mansx , @matl , @anh , @gc ;", new object[] { madia, tendia,sl,mansx,matl,anh,gc});;
        }

        public void SuaDia(string madia, string tendia, int sl, string mansx, string matl, string anh, string gc)
        {
            DataProvider.Instance.ExecuteNonQuery("exec SuaKhoDia @madia , @tendia , @sl , @mansx , @matl , @anh , @gc ;", new object[] { madia, tendia, sl, mansx, matl, anh, gc }); ;
        }

        public void DeleteDia(string madia)
        {
            DataProvider.Instance.ExecuteNonQuery("exec XoaDia @madia ;", new object[] { madia });
        }
        public int GetUnCheckDiaByMaDia(string madia)
        {
            DataTable data = DataProvider.Instance.ExecuteQuery("select * from dbo.tKhoDia where MaDoa=N'" + madia + "'");

            if (data.Rows.Count > 0)
            {
                Dia hdn = new Dia(data.Rows[0]);
                return 1;
            }

            return -1;
        }


    }


}
