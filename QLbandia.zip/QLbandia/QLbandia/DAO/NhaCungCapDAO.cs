﻿using QLbandia.dtos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLbandia.DAO
{
    public class NhaCungCapDAO
    {
        private static NhaCungCapDAO instance;

        public static NhaCungCapDAO Instance
        {
            get { if (instance == null) instance = new NhaCungCapDAO(); return NhaCungCapDAO.instance; }
            private set { NhaCungCapDAO.instance = value; }
        }


        public List<NhaCungCap> GetAllNhaCC()
        {
            List<NhaCungCap> listncc = new List<NhaCungCap>();

            string query = "select * from tNhaCungCap";
            DataTable data = DataProvider.Instance.ExecuteQuery(query);

            foreach(DataRow item in data.Rows)
            {
                NhaCungCap ncc = new NhaCungCap(item);
                listncc.Add(ncc);
            }

            return listncc;
        }
    }
}
