﻿using QLbandia.dtos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLbandia.DAO
{
    public class KhachHangDAO
    {
        private static KhachHangDAO instance;

        public static KhachHangDAO Instance
        {
            get { if (instance == null) instance = new KhachHangDAO(); return KhachHangDAO.instance; }
            private set { KhachHangDAO.instance = value; }
        }

        public List<KhachHang> GetAllKhachHang()
        {
            List<KhachHang> listkh = new List<KhachHang>();
            string query = "select * from tKhachHang";
            DataTable data = DataProvider.Instance.ExecuteQuery(query);

            foreach(DataRow item in data.Rows)
            {
                KhachHang kh = new KhachHang(item);
                listkh.Add(kh);
            }
            return listkh;
        }



    }
}
