﻿using QLbandia.dtos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLbandia.DAO
{
    public class NsxDAO
    {
        private static NsxDAO instance;

        public static NsxDAO Instance
        {
            get { if (instance == null) instance = new NsxDAO(); return NsxDAO.instance; }
            private set { NsxDAO.instance = value; }
        }
        private NsxDAO()
        {

        }
        public List<NSX> GetListCategory()
        {
            List<NSX> list = new List<NSX>();

            string query = "select * from tNoiSanXuat";

            DataTable data = DataProvider.Instance.ExecuteQuery(query);

            foreach (DataRow item in data.Rows)
            {
                NSX category = new NSX(item);
                list.Add(category);
            }

            return list;
        }

        public NSX GetCategoryByID(string id)
        {
            NSX category = null;

            string query = "select * from tTheLoai where MaTheLoai = " + id;

            DataTable data = DataProvider.Instance.ExecuteQuery(query);

            foreach (DataRow item in data.Rows)
            {
                category = new NSX(item);
                return category;
            }

            return category;
        }



        public void InsertNoiSX(string mansx, string tennsx)
        {
            DataProvider.Instance.ExecuteNonQuery("exec ThemNoiSX @mansx , @tennsx ;", new object[] { mansx, tennsx });
        }

        public void DeleteNoiSX(string mansx)
        {
            DataProvider.Instance.ExecuteNonQuery("exec XoaNSX @mansx ;", new object[] { mansx});
        }


        public void SuaNoiSX(string mansx,string tennsx)
        {
            DataProvider.Instance.ExecuteNonQuery("exec SuaNSX @mansx , @tennsx ;", new object[] { mansx, tennsx });
        }

        public int GetUnCheckNSXByMaNSX(string mansx)
        {
            DataTable data = DataProvider.Instance.ExecuteQuery("select * from dbo.tNoiSanXuat where MaNSX =N'" + mansx + "'");

            if (data.Rows.Count > 0)
            {
                NSX hdn = new NSX(data.Rows[0]);
                return 1;
            }

            return -1;
        }


        public List<NSX> LoadNoiSX()
        {
            List<NSX> nsxlist = new List<NSX>();

            DataTable data = DataProvider.Instance.ExecuteQuery("GetNoiSX");

            foreach (DataRow item in data.Rows)
            {
                NSX nsx = new NSX(item);
                nsxlist.Add(nsx);
            }

            return nsxlist;
        }


    }
}
