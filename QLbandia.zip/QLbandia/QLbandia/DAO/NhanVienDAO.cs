﻿using QLbandia.dtos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLbandia.DAO
{
    class NhanVienDAO
    {
        private static NhanVienDAO instance;

        public static NhanVienDAO Instance
        {
            get { if (instance == null) instance = new NhanVienDAO(); return NhanVienDAO.instance; }
            private set { NhanVienDAO.instance = value; }
        }
        private NhanVienDAO()
        {

        }

        public List<NhanVien> GetAllNhanVien()
        {
            List<NhanVien> listnv = new List<NhanVien>();

            string query = "select * from tNhanVien";
            DataTable data = DataProvider.Instance.ExecuteQuery(query);
            foreach (DataRow item in data.Rows) {
                NhanVien nv = new NhanVien(item);
                listnv.Add(nv);
            }
            return listnv;
        }


    }
}
