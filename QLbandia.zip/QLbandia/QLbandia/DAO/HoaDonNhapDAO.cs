﻿using QLbandia.dtos;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace QLbandia.DAO
{
    public class HoaDonNhapDAO
    {
        private static HoaDonNhapDAO instance;

        public static HoaDonNhapDAO Instance
        {
            get { if (instance == null) instance = new HoaDonNhapDAO(); return HoaDonNhapDAO.instance; }
            private set { HoaDonNhapDAO.instance = value; }
        }

        public void InsertHoaDonNhap(string shdn, string manv, string mancc)
        {
            DataProvider.Instance.ExecuteNonQuery("exec TaoHoaDonNhap @sohdn , @manv , @nhacc ;", new object[] { shdn, manv, mancc });
        }

        public int GetUnCheckHDByMaHD(string madh)
        {
            DataTable data = DataProvider.Instance.ExecuteQuery("select * from dbo.tHoaDonNhap where SoHDN =N'" + madh+ "'");

            if(data.Rows.Count > 0)
            {
                HoaDonNhap hdn = new HoaDonNhap(data.Rows[0]);
                return 1;
            }

            return -1;
        }


    }
}
