﻿using QLbandia.DAO;
using QLbandia.dtos;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace QLbandia
{
    public partial class fThemDia : Form
    {
        public fThemDia()
        {
            InitializeComponent();
            HienThi();
        }

        string fileAnh;


        public void HienThi()
        {
            cbNSX.SelectedIndex = -1;
            cbTheLoai.SelectedIndex = -1;
            LoadDia();
            HienTheLoaiTheoID();
            HienNSXTheoID();
        }

        public void LoadDia()
        {
            List<Dia> listdia = DiaDAO.Instance.LoadDiaList();
            dgvKhoDia.DataSource = listdia;
        }

        public void HienTheLoaiTheoID()
        {
            List<TheLoai> listTheLoai = TheLoaiDAO.Instance.GetListCategory();
            cbTheLoai.DataSource = listTheLoai;
            cbTheLoai.DisplayMember = "TenTL";
            cbTheLoai.ValueMember = "MaTL";
        }


        void HienNSXTheoID()
        {
            List<NSX> listTheLoai = NsxDAO.Instance.GetListCategory();
            cbNSX.DataSource = listTheLoai;
            cbNSX.DisplayMember = "TenNSX";
            cbNSX.ValueMember = "MANSX";
        }



        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnAnh_Click(object sender, EventArgs e)
        {
        

            OpenFileDialog open = new OpenFileDialog();
            // image filters  
            open.Filter = "Image Files(*.jpg; *.jpeg; *.gif; *.bmp)|*.jpg; *.jpeg; *.gif; *.bmp";
            if (open.ShowDialog() == DialogResult.OK)
            {
                // display image in picture box  
                ptAnh.Image = new Bitmap(open.FileName);
                // image file path  
                fileAnh = open.FileName;
            }

        }

        private void btnThem_Click(object sender, EventArgs e)
        {
            string madia = txtMaDia.Text;
            string tendia = txtTenDia.Text;
            int sl = Convert.ToInt32(txtSoLuong.Value);
            string mansx = cbNSX.SelectedValue.ToString();
            string mantl = cbTheLoai.SelectedValue.ToString();
            string gc = txtGhiChu.Text;
            string anh = fileAnh;
            int check = DiaDAO.Instance.GetUnCheckDiaByMaDia(madia);
            if (check == -1)
            {
                DiaDAO.Instance.InsertDia(madia, tendia, sl, mansx, mantl, anh, gc);
                HienThi();
                Refresh();
            }
            else
            {
                MessageBox.Show("Mã đĩa đã tồn tại");
                HienThi();
                Refresh();
            }

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvKhoDia_Click(object sender, EventArgs e)
        {
            txtMaDia.Text = dgvKhoDia.CurrentRow.Cells[0].Value.ToString();
            txtTenDia.Text= dgvKhoDia.CurrentRow.Cells[1].Value.ToString();
            cbNSX.SelectedItem= dgvKhoDia.CurrentRow.Cells[2].Value.ToString();
            cbTheLoai.SelectedItem= dgvKhoDia.CurrentRow.Cells[3].Value.ToString();
            txtGhiChu.Text= dgvKhoDia.CurrentRow.Cells[4].Value.ToString();
            fileAnh = dgvKhoDia.CurrentRow.Cells[5].Value.ToString();
            txtMaDia.Enabled = false;
        }

        private void btnSua_Click(object sender, EventArgs e)
        {
            string madia = txtMaDia.Text;
            string tendia = txtTenDia.Text;
            int sl = Convert.ToInt32(txtSoLuong.Value);
            string mansx = cbNSX.SelectedValue.ToString();
            string mantl = cbTheLoai.SelectedValue.ToString();
            string gc = txtGhiChu.Text;
            string anh = fileAnh;

            DiaDAO.Instance.SuaDia(madia, tendia, sl, mansx, mantl, gc, anh);
            HienThi();
            Refresh();

        }

        private void btnXoa_Click(object sender, EventArgs e)
        {   
            string madia= txtMaDia.Text;
            DiaDAO.Instance.DeleteDia(madia);
            HienThi();
            Refresh();
        }
    }
}
