
create database QuanLyBanDia
go

use QuanLyBanDia
go



SET ANSI_NULLS ON
GO
SET QUOTED_IDENTIFIER ON
GO 

CREATE TABLE [dbo].[tNoiSanXuat](
	[MaNSX] [nvarchar](10) NOT NULL,
	[TenNSX] [nvarchar](100) NULL,
 CONSTRAINT [PK_tNoiSanXuat] PRIMARY KEY CLUSTERED 
(
	[MaNSX] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


CREATE TABLE [dbo].[tTheLoai](
	[MaTL] [nvarchar](10) NOT NULL,
	[TenTL] [nvarchar](100) NULL,
 CONSTRAINT [PK_tTheLoai] PRIMARY KEY CLUSTERED 
(
	[MaTL] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


CREATE TABLE [dbo].[tNhanVien](
	[MaNV] [nvarchar](10) NOT NULL,
	[TenNV] [nvarchar](100) NULL,
	[GioiTinh] [nvarchar](100) NULL,
	[NgaySinh] date NULL,
	[DienThoai] [nvarchar](100) NULL,
	[DiaChi] [nvarchar](100) NULL,
	[MaCV] [nvarchar](100) NULL,
 CONSTRAINT [PK_tNhanVien] PRIMARY KEY CLUSTERED 
(
	[MaNV] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
ALTER TABLE tNhanVien
ALTER COLUMN MaCV [nvarchar](10) NULL


CREATE TABLE [dbo].[tCongViec](
	[MaCV] [nvarchar](10) NOT NULL,
	[TenCV] [nvarchar](100) NULL,
 CONSTRAINT [PK_tCongViec] PRIMARY KEY CLUSTERED 
(
	[MaCV] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


CREATE TABLE [dbo].[tNhaCungCap](
	[MaNCC] [nvarchar](10) NOT NULL,
	[TenNCC] [nvarchar](100) NULL,
	[DiaChi] [nvarchar](100) NULL,
	[DienThoai] [nvarchar](100) NULL,
 CONSTRAINT [PK_tNhaCungCap] PRIMARY KEY CLUSTERED 
(
	[MaNCC] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


CREATE TABLE [dbo].[tKhoDia](
	[MaDia] [nvarchar](10) NOT NULL,
	[TenDia] [nvarchar](100) NULL,
	[SoLuong] int NULL,
	[DonGiaBan] float Null,
	[DonGiaNhap] float NULL,
	[MaNSX] [nvarchar](10) NULL,
	[MaTL] [nvarchar](10) NULL,
	[Anh] [nvarchar](100) NULL,
	[GhiChu] [nvarchar](500) NULL,
 CONSTRAINT [PK_tKhoDia] PRIMARY KEY CLUSTERED 
(
	[MaDia] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


CREATE TABLE [dbo].[tChiTietHDB](
	[SoHDB] [nvarchar](10) NOT NULL,
	[MaDia] [nvarchar](10) NOT NULL,
	[DiaChi] [nvarchar](100) NULL,
	[DienThoai] [nvarchar](100) NULL,
 CONSTRAINT [PK_tChiTietHDB] PRIMARY KEY CLUSTERED 
(
	[SoHDB] ASC,
	[MaDia] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


CREATE TABLE [dbo].[tChiTietHDN](
	[SoHDN] [nvarchar](10) NOT NULL,
	[MaDia] [nvarchar](10) NOT NULL,
	[SoLuong] int NULL,
	[GiamGia] Float NUll,
	[ThanhTien] float NULL,
 CONSTRAINT [PK_tChiTietHDN] PRIMARY KEY CLUSTERED 
(
	[SoHDN] ASC,
	[MaDia] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


CREATE TABLE [dbo].[tMatHongDia](
	[SoLanMat] [nvarchar](10) NOT NULL,
	[MaDia] [nvarchar](10) NOT NULL,
	[SoLuongMat] [nvarchar](100) NULL,
	[NgayMat] datetime NULL,
 CONSTRAINT [PK_tMatHongDia] PRIMARY KEY CLUSTERED 
(
	[SoLanMat] ASC,
	[MaDia] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


CREATE TABLE [dbo].[tHoaDonBan](
	[SoHDB] [nvarchar](10) NOT NULL,
	[MaNV] [nvarchar](10) NOT NULL,
	[NgayBan] datetime NULL,
	[MaKH] [nvarchar](10) NULL,
	[TongTien] float NULL,
 CONSTRAINT [PK_tHoaDonBan] PRIMARY KEY CLUSTERED 
(
	[SoHDB] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]
ALTER TABLE tHoaDonBan
ALTER COLUMN [MaNV] [nvarchar](10) NULL

CREATE TABLE [dbo].[tHoaDonNhap](
	[SoHDN] [nvarchar](10) NOT NULL,
	[MaNV] [nvarchar](10) NOT NULL,
	[NgayNhap] datetime NULL,
	[MaNCC] [nvarchar](10) NULL,
	[TongTien] float NULL,
 CONSTRAINT [PK_tHoaDonNhap] PRIMARY KEY CLUSTERED 
(
	[SoHDN] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]

ALTER TABLE tHoaDonNhap
ALTER COLUMN [MaNV] [nvarchar](10) NULL


CREATE TABLE [dbo].[tKhachHang](
	[MaKH] [nvarchar](10) NOT NULL,
	[TenKH] [nvarchar](100) NULL,
	[DiaChi] [nvarchar](100) NULL,
	[DienThoai] [nvarchar](100) NULL,
 CONSTRAINT [PK_tKhachHang] PRIMARY KEY CLUSTERED 
(
	[MaKH] ASC
)WITH (PAD_INDEX = OFF, STATISTICS_NORECOMPUTE = OFF, IGNORE_DUP_KEY = OFF, ALLOW_ROW_LOCKS = ON, ALLOW_PAGE_LOCKS = ON, OPTIMIZE_FOR_SEQUENTIAL_KEY = OFF) ON [PRIMARY]
) ON [PRIMARY]


ALTER TABLE [dbo].[tKhoDia]  WITH CHECK ADD  CONSTRAINT [FK_KhoDia_tNoiSanXuat] FOREIGN KEY([MaNSX])
REFERENCES [dbo].[tNoiSanXuat] ([MaNSX])
GO

ALTER TABLE [dbo].[tKhoDia]  WITH CHECK ADD  CONSTRAINT [FK_KhoDia_tTheLoai] FOREIGN KEY([MaTL])
REFERENCES [dbo].[tTheLoai] ([MaTL])
GO

ALTER TABLE [dbo].[tNhanVien]  WITH CHECK ADD  CONSTRAINT [FK_tNhanVien_tCongViec] FOREIGN KEY([MaCV])
REFERENCES [dbo].[tCongViec] ([MaCV])
GO


ALTER TABLE [dbo].[tChiTietHDB]  WITH CHECK ADD  CONSTRAINT [FK_tChiTietHDB_tKhoDia] FOREIGN KEY([MaDia])
REFERENCES [dbo].[tKhoDia] ([MaDia])
GO

ALTER TABLE [dbo].[tChiTietHDB]  WITH CHECK ADD  CONSTRAINT [FK_tChiTietHDB_tHoaDonBan] FOREIGN KEY([SoHDB])
REFERENCES [dbo].[tHoaDonBan] ([SoHDB])
GO


ALTER TABLE [dbo].[tChiTietHDN]  WITH CHECK ADD  CONSTRAINT [FK_tChiTietHDN_tKhoDia] FOREIGN KEY([MaDia])
REFERENCES [dbo].[tKhoDia] ([MaDia])
GO

ALTER TABLE [dbo].[tChiTietHDN]  WITH CHECK ADD  CONSTRAINT [FK_tChiTietHDN_tHoaDonNhap] FOREIGN KEY([SoHDN])
REFERENCES [dbo].[tHoaDonNhap] ([SoHDN])
GO

ALTER TABLE [dbo].[tMatHongDia]  WITH CHECK ADD  CONSTRAINT [FK_tMatHongDia_tKhoDia] FOREIGN KEY([MaDia])
REFERENCES [dbo].[tKhoDia] ([MaDia])
GO

ALTER TABLE [dbo].[tHoaDonBan]  WITH CHECK ADD  CONSTRAINT [FK_tChiTietHDB_tNhanVien] FOREIGN KEY([MaNV])
REFERENCES [dbo].[tNhanVien] ([MaNV])
GO

ALTER TABLE [dbo].[tHoaDonBan]  WITH CHECK ADD  CONSTRAINT [FK_tHoaDonBan_tKhachHang] FOREIGN KEY([MaKH])
REFERENCES [dbo].[tKhachHang] ([MaKH])
GO

ALTER TABLE [dbo].[tHoaDonNhap]  WITH CHECK ADD  CONSTRAINT [FK_tHoaDonNhap_tNhanVien] FOREIGN KEY([MaNV])
REFERENCES [dbo].[tNhanVien] ([MaNV])
GO

ALTER TABLE [dbo].[tHoaDonNhap]  WITH CHECK ADD  CONSTRAINT [FK_tHoaDonNhap_tNhaCungCap] FOREIGN KEY([MaNCC])
REFERENCES [dbo].[tNhaCungCap] ([MaNCC])
GO






	--trigger

		--1
		alter trigger UpdateKhoDia
		on tChiTietHDN
		after insert
		as begin
			declare @mahdn nvarchar(10), @madia nvarchar(10),@slkho int, @slnhap int, @dg float, @tongtienhd float, @tienctht float
			select @mahdn = SoHDN from inserted
			select @madia = MaDia from inserted
			select @slnhap = SoLuong from inserted
			select @dg = DonGia from inserted
			select @slkho = SoLuong from tKhoDia where MaDia = @madia
			
			select @tongtienhd = sum(cthdn.ThanhTien) from tHoaDonNhap hdn join tChiTietHDN cthdn on hdn.SoHDN = cthdn.SoHDN
				where cthdn.SoHDN = @mahdn
				group by cthdn.SoHDN

		
			update tKhoDia set SoLuong = @slkho + @slnhap where MaDia = @madia
			update tKhoDia set DonGiaNhap = @dg where MaDia = @madia
			update tKhoDia set DonGiaBan = @dg*1.1 where MaDia = @madia
			update tChiTietHDN set ThanhTien = @dg*@slnhap where SoHDN = @mahdn and MaDia = @madia
			update tHoaDonNhap set TongTien = @tongtienhd + @dg*@slnhap where SoHDN = @mahdn
		end
		--2

		--trigger khi them hoa don ban

		alter trigger CapNhatHoaDon
		on tChiTietHDB
		after insert
		as begin
			declare @mahdb nvarchar(10), @madia nvarchar(10),@giadia float, @tongtienct float, @tongtienhdb float, @soluongmua int, @sldiaconlai int

			select @mahdb = SoHDB from inserted
			select @madia = MaDia from inserted
			select @giadia = DonGiaBan from tKhoDia where MaDia = @madia
			select @soluongmua = SoLuong from inserted
			select @sldiaconlai = SoLuong from tKhoDia where MaDia = @madia

			select @tongtienhdb = sum(cthdb.ThanhTien) from tHoaDonBan hdb join tChiTietHDB cthdb on hdb.SoHDB = cthdb.SoHDB
				where cthdb.SoHDB = @mahdb
				group by cthdb.SoHDB


			update tChiTietHDB set ThanhTien = @giadia * @soluongmua where SoHDB = @mahdb
			update tHoaDonBan set TongTien = @tongtienhdb + @giadia*@soluongmua where SoHDB = @mahdb
			update tKhoDia set SoLuong = @sldiaconlai - @soluongmua

		end
		
		select sum(cthdn.ThanhTien) from tHoaDonNhap hdn join tChiTietHDN cthdn on hdn.SoHDN = cthdn.SoHDN
			where cthdn.SoHDN = N'HD2'
			group by cthdn.SoHDN

		use QuanLyBanDia
		go

	-- procedure
		exec USP_GetAlbumList

		exec TaoHoaDonNhap @sohdn = N'HD2', @manv = N'HIEUTT1', @nhacc = N'NCC01';

		--insert hoadonnhap
		CREATE PROC [dbo].[TaoHoaDonNhap]
		@sohdn nvarchar(10), @manv nvarchar(10), @nhacc nvarchar(10)
		AS
		BEGIN
			INSERT dbo.tHoaDonNhap 
					( SoHDN ,
					  MaNV ,
					  NgayNhap ,
					  MaNCC,
					  TongTien
					)
			VALUES  ( 
					  @sohdn,
					  @manv,
					  GETDATE() , 
					  @nhacc, 
					  0
					)
		END
		GO
		

		create proc InsertDia @


				exec USP_GetAlbumList

		exec TaoHoaDonNhap @sohdn = N'HD2', @manv = N'HIEUTT1', @nhacc = N'NCC01';

		exec ThemChiTietHoaDonNhap @sohdn = N'HD2', @madia = N'CDMON', @soluong = 20;

		--insert chitiethoadonnhap
		alter PROC [dbo].[ThemChiTietHoaDonNhap]
		@sohdn nvarchar(10), @madia nvarchar(10), @soluong int
		AS
		BEGIN
			declare @gia float
			select @gia = DonGiaNhap from tKhoDia where MaDia = @madia
			INSERT dbo.tChiTietHDN 
					( SoHDN ,
					  MaDia ,
					  SoLuong ,
					  GiamGia,
					  DonGia,
					  ThanhTien
					)
			VALUES  ( 
					  @sohdn,
					  @madia,
					  @soluong ,
					  1,
					  @gia, 
					  0
					)
		END
		GO

		select * from tKhoDia



		--  insert hoa don ban
		create PROC [dbo].[ThemHoaDonBan]
		@sohdb nvarchar(10), @manv nvarchar(10), @makh nvarchar(30)
		AS
		BEGIN
			declare @ float
			select @gia = DonGiaBan from tKhoDia where MaDia = @madia
			INSERT dbo.tChiTietHDN 
					( SoHDB ,
					  MaNV ,
					  NgayBan ,
					  MaKH,
					  TongTien
					)
			VALUES  ( 
					  @sohdb,
					  @manv,
					  GETDATE(),
					  @makh,
					  @gia, 

					  0
					)
		END
		GO

		-- insert hoa don nhap

		USE [QuanLyBanDia]
		GO

		INSERT INTO [dbo].[tHoaDonBan]
           ([SoHDB]
           ,[MaNV]
           ,[NgayBan]
           ,[MaKH]
           ,[TongTien])
		 VALUES
           (N'HD1'
           ,N'HIEUTT1'
           ,GETDATE()
           ,N'KH01'
           ,0
		)

		USE [QuanLyBanDia]
GO

INSERT INTO [dbo].[tChiTietHDB]
           ([SoHDB]
           ,[MaDia]
           ,[DiaChi]
           ,[DienThoai]
           ,[SoLuong]
           ,[GiamGia]
           ,[ThanhTien])
     VALUES
           (N'HD1'
           ,N'CDGOW'
           ,N'Ha Noi'
           ,N'123123123'
           ,2
           ,1
           ,0)
GO



		select * from tHoaDonNhap
		select * from tChiTietHDN


		select * from tChiTietHDB
		select * from tKhoDia
		select * from tHoaDonBan

		alter table tChiTietHDB
		add ThanhTien float

		select * from tKhachHang

		insert into tKhachHang(
		MaKH,
		TenKH,
		DiaChi,
		DienThoai
		)values(
		N'KH01',
		N'DangHuyHoang',
		N'H� n?i',
		09899111
		)

		use QuanLyBanDia

		select * from tKhachHang





		select * from tTheLoai


		create or alter proc ThemNoiSX @mansx nvarchar(10), @tennsx nvarchar(100)
		as
		begin 
			insert tNoiSanXuat(MaNSX,TenNSX) Values (@mansx,@tennsx)
		end

		create or alter proc XoaNSX @mansx nvarchar(10)
		as begin 
			Delete from tNoiSanXuat where MaNSX=@mansx
		end

		create or alter proc SuaNSX @mansx nvarchar(10), @tennsx nvarchar(100)
		as
		begin
			update  tNoiSanXuat set MaNSX=@mansx , TenNSX = @tennsx where MaNSX=@mansx
		end


		create proc GetNoiSX 
		as begin
			select * from tNoiSanXuat
		end


	
		create or alter proc ThemTheLoai @matl nvarchar(10), @tentl nvarchar(100)
		as
		begin 
			insert tTheLoai(MaTL,TenTL) Values (@matl,@tentl)
		end

		create or alter proc XoaTL @matl nvarchar(10)
		as begin 
			Delete from tTheLoai where MaTL=@matl
		end

		create or alter proc SuaTL @matl nvarchar(10), @tentl nvarchar(100)
		as
		begin
			update  tTheLoai set MaTL=@matl , TenTL = @tentl where MaTL=@matl
		end



		create proc GetTheloai
		as begin
			select * from tTheLoai
		end





		create or alter proc ThemDia @madia nvarchar(10), @tendia nvarchar(100), @sl int, @mansx nvarchar(10), @matl nvarchar(10), @anh nvarchar(300), @gc nvarchar
		as begin
			insert tKhoDia(
				MaDia,
				TenDia,
				SoLuong,
				DonGiaBan,
				DonGiaNhap,
				MaNSX,
				MaTL,
				Anh,
				GhiChu
			)Values
			(
			@madia,
			@tendia,
			@sl,
			0,
			0,
			@mansx,
			@matl,
			@anh,
			@gc
			)
		end


		create or alter proc SuaKhoDia @madia nvarchar(10), @tendia nvarchar(100), @sl int, @mansx nvarchar(10), @matl nvarchar(10), @anh nvarchar(300), @gc nvarchar
		as begin
			update tKhoDia set MaDia=@madia, TenDia=@tendia, SoLuong = @sl, MaNSX = @mansx, MaTL=@matl, Anh=@anh, GhiChu=@gc where MaDia=@madia
			
		end

		create or alter proc XoaDia @madia nvarchar(10)
		as begin 
			delete from tKhoDia where MaDia=@madia
		end


		exec ThemDia @madia=N'dd', @tendia=N'asdasda',@sl=33,@mansx = N'N06',@matl=N'T01',@anh=N'',@gc=N''

		select * from tKhoDia

		delete from tKhoDia where MaDia=N'D12'
		






		exec GetNoiSX

		

		exec USP_GetAlbumList







		select * from tTheLoai

		select * from tNhanVien

		select * from tNoiSanXuat

		alter table tNhanVien
		drop MatKhau


